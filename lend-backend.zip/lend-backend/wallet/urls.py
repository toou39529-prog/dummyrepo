from django.urls import path
from . import views

urlpatterns = [
    path('balance/', views.get_balance, name='wallet-balance'),
]