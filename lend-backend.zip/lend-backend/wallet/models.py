from django.db import models

# Create your models here.
from django.db import models
from django.conf import settings

class Wallet(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                               related_name='wallet')
    address = models.CharField(max_length=255, unique=True, db_index=True)
    balance_sats = models.BigIntegerField(default=0)
    balance_bch = models.DecimalField(max_digits=20, decimal_places=8, default=0)
    last_sync = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user} - {self.address[:15]}..."