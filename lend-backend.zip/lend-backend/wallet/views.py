from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from .models import Wallet
from .bch_utils import BCHUtils

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_balance(request):
    """GET /api/wallet/balance/ - Get wallet balance"""
    
    try:
        # Get user's wallet
        wallet = request.user.wallet
        
        # Fetch fresh balance from blockchain
        balance_data = BCHUtils.get_balance(wallet.address)
        
        # Update stored balance
        wallet.balance_sats = balance_data['balance_sats']
        wallet.balance_bch = balance_data['balance_bch']
        wallet.last_sync = timezone.now()
        wallet.save()
        
        return JsonResponse({
            'balance': balance_data['balance']  # "0.000" format
        })
        
    except Wallet.DoesNotExist:
        return JsonResponse({
            'balance': '0.000'
        })
    except Exception as e:
        return JsonResponse({
            'balance': '0.000'
        })