from django.apps import AppConfig


class BchSessionsConfig(AppConfig):
    name = 'bch_sessions'
