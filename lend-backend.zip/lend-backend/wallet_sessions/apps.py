from django.apps import AppConfig


class WalletSessionsConfig(AppConfig):
    name = 'wallet_sessions'
